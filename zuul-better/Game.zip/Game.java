import java.util.*;
/**
 *  This class is the main class of the "World of Zuul" application. 
 *  "World of Zuul" is a very simple, text based adventure game.  Users 
 *  can walk around some scenery. That's all. It should really be extended 
 *  to make it more interesting!
 * 
 *  To play this game, create an instance of this class and call the "play"
 *  method.
 * 
 *  This main class creates and initialises all the others: it creates all
 *  rooms, creates the parser and starts the game.  It also evaluates and
 *  executes the commands that the parser returns.
 * 
 * @author  Michael Kölling and David J. Barnes
 * @version 2016.02.29
 */

public class Game 
{
    private Parser parser;
    public Room currentRoom;
    public ArrayList<Entity> equipment;
    public int hp;
    private Entity hillichurl;
    public int combat_power;
    public Player player;
    public Room previous_room;
    Room start, monster_camp1, monster_camp2, monster_camp4, monster_camp3,weapon_room,treasure_room1,treasure_room2,companion_room,misc_room,mini_boss,boss_room,transporter_room;
    Character companion;
    ArrayList<Room> visited;
    public Teleporter teleporter;
    ArrayList<String> direction;
    Entity treasure_key;
    /**
     * Create the game and initialise its internal map.
     */
    public Game() 
    {      
        visited = new ArrayList<>();
        equipment = new ArrayList<>();
        equipment.add((new Entity(false,this,100,"Sword",true,null,0.5)));
        equipment.add((new Entity(false,this,100,"Shield",true,null,0.5)));
        equipment.add((new Entity(false,this,0,"Medicine",false,null,0.5)));
        createRooms();
        teleporter = new Teleporter(this,weapon_room);
        hp = 10000;
        combat_power = 200;
        parser = new Parser();
        player = new Player(this,equipment,hp,combat_power,false,"Ronen");
        player.setMaxWeight(2.0);
        ArrayList<Entity> comp1 = new ArrayList<>();
        companion= new Character(false,this,comp1,2000,200,true,"Zhongli");
        Room start, monster_camp1, monster_camp2, monster_camp4, monster_camp3,weapon_room,treasure_room1,treasure_room2,companion_room,misc_room,mini_boss,boss_room,transporter_room;
        direction = new ArrayList<>();
        direction.add("north");
        direction.add("south");
        direction.add("east");
        direction.add("west");
    }
    public void updateCombatPower()
    {   
        if(companion.is_companion())
        {
            player.combat_power = companion.equipment.get(0).combat_power+player.equipment.get(0).combat_power + player.equipment.get(1).combat_power;
        }
        else
        {
            player.combat_power = player.equipment.get(0).combat_power + player.equipment.get(1).combat_power;
        }
    }
    public void showCombatPower()
    {
        System.out.println("Your combat power is : " + player.combat_power);
    }
    /**
     * Create all the rooms and link their exits together.
     */
    private void createRooms()
    {
          
        // create the rooms
        start = new Room("1");
        monster_camp1 = new Room("2");
        monster_camp4 = new Room("3");
        monster_camp2= new Room("4");
        monster_camp3 = new Room("5");
        weapon_room = new Room("6");
        companion_room = new Room("7");
        mini_boss = new Room("8");
        boss_room = new Room("9");
        treasure_room1 = new Room("10");
        treasure_room2 = new Room("11");
        misc_room = new Room("12");
        transporter_room = new Room("Transporter_Room");
        // initialise room exits
        start.setExit("east", weapon_room);
        start.setExit("south",monster_camp1);
        start.setExit("west",transporter_room);
        
        transporter_room.setExit("east",start);
        weapon_room.setExit("west",start);
        weapon_room.entities.add(new Entity(false,this,150,"silver sword",true,null,0.4));
        weapon_room.entities.add(new Entity(false,this,200,"spartan shield",true,null,0.5));
        treasure_key = new Entity(false,this,0,"iron key",true,null,0.1);
        weapon_room.entities.add(treasure_key);
        
        transporter_room.is_locked(treasure_key);
        ArrayList<Entity> treasure_items1 = new ArrayList<Entity>();
        treasure_items1.add((new Entity(false,this,200,"gold sword",true,null,0.3)));
        treasure_items1.add((new Entity(false,this,200,"bronze shield",true,null,0.2)));
        weapon_room.entities.add((new Entity(true,this,0,"Treasure_Chest",false,treasure_items1,0.1)));
        ArrayList<Entity> comp1 = new ArrayList<>();
        weapon_room.characters.add(companion);    
        monster_camp1.setExit("north",start);
        monster_camp1.setExit("west",monster_camp2);
        monster_camp1.setExit("south",companion_room);
        ArrayList<Entity> drop1 = new ArrayList<>();
        drop1.add(new Entity(false,this,0,"medicine",true,null,0.3));
        monster_camp1.characters.add(new Character(false,this,drop1,2000,200,true,"Hillichurl_pack"));
        monster_camp1.entities.add(new Entity(false,this,200,"Treasure Key",false,null,0.5));
        
        monster_camp2.setExit("south",treasure_room1);
        monster_camp2.setExit("east",monster_camp1);

        companion_room.setExit("north",monster_camp1);
        companion_room.setExit("west",monster_camp4);
        companion_room.setExit("south",mini_boss);

        monster_camp4.setExit("east",companion_room);
        
        mini_boss.setExit("north",companion_room);
        mini_boss.setExit("west",treasure_room2);
        mini_boss.setExit("south",monster_camp3);
        
        monster_camp3.setExit("north",mini_boss);
        monster_camp3.setExit("east",misc_room);
        monster_camp3.setExit("south",boss_room);

        misc_room.setExit("west",monster_camp3);
        
        boss_room.setExit("north",monster_camp3);
        

        currentRoom = start;  // start game outside
        previous_room = start;
    }

    /**
     *  Main play routine.  Loops until end of play.
     */
    public void play() 
    {            
        printWelcome();

        // Enter the main command loop.  Here we repeatedly read commands and
        // execute them until the game is over.
                
        boolean finished = false;
        while (! finished) {
            Command command = parser.getCommand();
            finished = processCommand(command);
        }
        System.out.println("Thank you for playing.  Good bye.");
    }

    /**
     * Print out the opening message for the player.
     */
    private void printWelcome()
    {
        System.out.println();
        System.out.println("Welcome to the World of Zuul!");
        System.out.println("World of Zuul is a new, incredibly boring adventure game.");
        System.out.println("Type 'help' if you need help.");
        System.out.println();
        System.out.println(currentRoom.getLongDescription());
    }

    /**
     * Given a command, process (that is: execute) the command.
     * @param command The command to be processed.
     * @return true If the command ends the game, false otherwise.
     */
    private boolean processCommand(Command command) 
    {
        boolean wantToQuit = false;
        if(command.isUnknown()) {
            System.out.println("I don't know what you mean...");
            return false;
        }

        String commandWord = command.getCommandWord();
        if (commandWord.equals("help")) {
            printHelp();
        }
        else if (commandWord.equals("go")) {
            previous_room = currentRoom;
            player.goRoom(command);
            if(currentRoom != previous_room)
            {
                if(!currentRoom.is_visited())
                {   
                    currentRoom.has_been_visited(true);
                    if(teleporter.teleporter_room() != currentRoom)
                    {
                        visited.add(currentRoom);
                    }
                    System.out.println(currentRoom.getLongDescription());
                }
                else
                {
                    System.out.println("You have already visited this room.");
                }
            }
            }
        else if (commandWord.equals("quit")) {
            wantToQuit = quit(command);
        }
        else if(commandWord.equals("inventory")){
            inventory();
        }
        else if(commandWord.equals("take")){
            String item = command.getSecondWord() +" "+  command.getThirdWord();
            if(command.getFifthWord() == null){
                player.take_item(item,this.currentRoom.entities);
                updateCombatPower();
                showCombatPower();
            }
            else
            {
                player.take_item_from_chest(command);
                updateCombatPower();
                showCombatPower();
            }
        }
        else if(commandWord.equals("open")){
            player.open_chest();
            }
        else if(commandWord.equals("inspect")){
            currentRoom.show_items();
        }
        else if(commandWord.equals("back")){
            player.goBack();
            if(companion.is_companion())
            {
                companion.goBack();
            }
            System.out.println(currentRoom.getLongDescription());
        }
        else if(commandWord.equals("attack")){
            player.attack(command.getSecondWord());
        }
        else if(commandWord.equals("give")){
            if(command.getFourthWord() == null)
            {
                player.give(command.getThirdWord(),find_entity(command.getSecondWord()));
                player.equipment.remove(player.equipment.indexOf(find_entity(command.getSecondWord().toLowerCase())));
            }
            else
            {   
                String item = command.getSecondWord() + " " + command.getThirdWord();
                player.give(command.getFourthWord(),find_entity(item));
                player.equipment.remove(player.equipment.indexOf(find_entity(item)));
            }
            companion.to_companion();
        }
        else if(commandWord.equals("use"))
        {
            if(command.getSecondWord().equalsIgnoreCase("teleporter")  && this.currentRoom == teleporter.teleporter_room());
            {
                teleporter.teleport();
            }
        }
        else if(commandWord.equals("unlock"))
        {
            if(direction.contains(command.getSecondWord()))
            {
                player.unlockRoom(command.getSecondWord());
            }
        }
        else if(commandWord.equals("drop"))
        {
            String item = command.getSecondWord();
            for(int i = 0;i<player.equipment.size();i++)
            {   
                if(player.equipment.get(i).name.equalsIgnoreCase(item))
                {   
                    if(i > 1)
                    {
                        currentRoom.entities.add(player.equipment.get(i));
                        player.equipment.remove(i);
                        break;
                    }
                    else
                    {
                        System.out.println("You cant drop ur equipment!");
                    }
                }
            }
        }
        // else command not recognised.
        return wantToQuit;
    }
    public Entity find_entity(String word)
    {   
        for(Entity entity:player.equipment)
        {
            if(entity.name.equalsIgnoreCase(word))
            {
                return entity;
            }   
        }
        return null;
    }

    // implementations of user commands:

    /**
     * Print out some help information.
     * Here we print some stupid, cryptic message and a list of the 
     * command words.
     */
    private void printHelp() 
    {
        System.out.println("You are lost. You are alone. You wander");
        System.out.println("around at the university.");
        System.out.println();
        System.out.println("Your command words are:");
        parser.showCommands();
    }

    /** 
     * Try to in to one direction. If there is an exit, enter the new
     * room, otherwise print an error message.
     */
    /** 
     * "Quit" was entered. Check the rest of the command to see
     * whether we really quit the game.
     * @return true, if this command quits the game, false otherwise.
     */
    private boolean quit(Command command) 
    {
        if(command.hasSecondWord()) {
            System.out.println("Quit what?");
            return false;
        }
        else {
            return true;  // signal that we want to quit
        }
    }
    private void inventory()
    {   
        System.out.println("Inventory");
        int i = 1;
        for(Entity key:equipment)
        {   
            System.out.println(i+". " + key.name);
            i++;
        }
    }
    public static void main()
    {
    	Game game = new Game();
    	game.play();
    }
}
